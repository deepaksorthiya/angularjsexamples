/**
 * @author Chris
 * Date : 01/12/2017
 */

(function() {
var vLoadModues = ['providerlookup', 'stafflookup',
                   'facilitylookup', 'facilitygrouplookup', 'oc.lazyLoad',  
                   'patientlookup', 'lablookup','preferenceCardlookup','ecw.service.newApptService','ecw.dir.datepicker', 'ecw.dir.maskdateinput','ecw.dir.ipDatePicker',
                   'inPatient.dir.IP-CPT-ICDAutoSuggest','daterangepicker','ui.mask',
                   'ecw.dir.inlineDepartmentLookup','ecw.dir.inlineUnitLookup','ecw.dir.inlineBedLookup','ecw.dir.inlineFacilityLookup'
                   ];

 angular.module('patientEncounterModule', vLoadModues).controller('newPtEncounterController',['$scope','$http','$ocLazyLoad','newApptService','$timeout','$modalInstance','ptdata','callBack','masterEncId','bedAreaData','subEncId','singleTimeOpt','singleDateOpt','$modal',encounterModalCtrl]);
function encounterModalCtrl($scope , $http, $ocLazyLoad,newApptService,$timeout,$modalInstance,ptdata,callBack,masterEncId,bedAreaData,subEncId,singleTimeOpt,singleDateOpt,$modal) {
		$scope.mandatoryFieldName = "";
		$scope.alertmsg = "";
		$scope.dirty_flag = false;
		$scope.selectedServiceType = "";
		$scope.selectedEncStatusId="";
		$scope.selectedEncStatusName="";
		$scope.selectedEncStatusDate="";
		$scope.subEncCount='(0)';
		$scope.encPatientType=[];
		$scope.encServiceType=[];
		$scope.eSIAcuity=[];
		$scope.PatientTypeValue='Select';
		$scope.ServiceTypeValue='Select';
		$scope.setEncounterData= [];
		$scope.EncMappedData = "";
		$scope.testData="";
		$scope.AdmissionSourceData = [];
		$scope.methodOfArrivalData = [];
		$scope.patientGender='';
		$scope.patientEncServiceType = "";
		$scope.callbackEnc = callBack;
		$scope.masterEncId = masterEncId;
		$scope.selectedPatient = ptdata;
		$scope.bedAreaData = bedAreaData;
		$scope.subEncId = subEncId;
		$scope.diagnosisIndex = '';
		$scope.diagnosisIndex = '';
		$scope.currentLocation = '';
		$scope.disabledDept = true;
		$scope.disabledUnitBed = true;
		$scope.disabledFacility = false;
		$scope.encounterTab = '';
		$scope.ResceduledStatusId = '';
		$scope.ResceduledRequestStatusId = '';
		$scope.EncounterResceduled = false;
		$scope.CancelStatusId = '';
		$scope.FullReg = '';
		$scope.singleTimeOpt = singleTimeOpt;
		$scope.baseStartDate = moment("01/01/1900 03:00:00", "MM/DD/YYYY HH:mm:ss");
		
		
		$scope.masterEncData={};
		$scope.AdmittingProvider={provider:{}};
		$scope.AttendingProvider={provider:{}};
		$scope.selFacility={facility:{}};
		$scope.userMapList={};
		$scope.defaultInpatientFlag = false;
		$scope.defaultOutPatientFlag = true;
		$scope.EditEnc = false;
		$scope.setDiagnosisTimeout = '';
		$scope.servicenameDiagnosisMapping = [{'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]}];
		
		
		$scope.selectedDept = {};
		$scope.momentDate = {};
		$scope.momentMasterAdmitDate = '';
		$scope.momentMasterDischargeDate = '';
		$scope.momentMasterEncounterDate = '';
		$scope.momentObrStartDate = '';
		$scope.momentObrEndDate = '';
		$scope.selectedUnit = {};
		$scope.selectedBed = {};
		$scope.roomType = [];
		$scope.setFacility = false;
		$scope.setBedData = false;
		$scope.setGetServerData = false;
		
		
		$scope.onSelectDept="";
		$scope.onSelectUnit="";
		$scope.pageParam = {pageIndex : 0, maxCount : 5};
		$scope.currentServiceIndex ='';
		$scope.currentDiagnosisIndex ='';
		$scope.dxType ='';
		$scope.dxCode ='';
		$scope.dxDesc ='';
		$scope.counter = 0;
		$scope.SerNameMandate = false;
		$scope.userFullName = '';
		$scope.obrPtType = [];
		$scope.disableObrPtType = true;
		$scope.obrUser = {startUser:'',endUser:''};
		$scope.encNote = {noteText:'',userId:'',noteId:'',timestamp:'',id:''};
		$scope.appontmentText = '';
		$scope.servDeptMapFlag = false;

		$timeout(function(){$('#newEncounter').find('.all-timeline').perfectScrollbar();},1000);
        
		
		
		
		//$scope.onSelectBed=setEncBedObject;
		
		$scope.subEncRecvData={subEncId:'',masterEncId:'',status:''};
		$scope.subEncDataList ={};
		$scope.DisplayDataJson = {patientType:'Select',serviceType:'Select',serviceName:'Select',admissionType:'Select',admissionSource:'Select',methodOfArrival:'Select',EsiAcuity:'Select',selectedServiceType:'',selectedDignosisList:'',roomTypeName:'Select'};
		$scope.newEncounterData={masterEncAdmitDateTime:'',masterEncDischargeDateTime:'',masterEncId:'',subEncId:'',encounterType:'',encounterSelectedStatus:'',selectedEncStatusDate:'',serviceTypeName:'',encounterSelectedStatusId:'',encounterStatus:'',patientType:'',serviceType:'',serviceName:'',admissionType:'',admissionSource:'',methodOfArrival:'',
			esiAcuity:'',statedVisitRegion:'',diagnosis:[],isConfidentialEnc:'',isNewPatient:'',transitionOfCare:'',encDateTime:'',AdmittingProvider:'',AdmittingProviderName:'',AttendingProvider:'',AttendingProviderName:'',facility:'',facilityName:'',department:'',unit:'',obrStartdate:'',obrEnddate:'',
			bed:'0',roomType:'0',LevelOfCare:'',currentLocation:'',patientid:'',diagnosisChanged:'',obrEndUserId:0,obrStartUserId:0,deptDescipline:'',serviceDiagnosisMap:[],encNoteList:[],isAppointment:false,changeFlag:false,ptInfoVerified:false,verifyPtInfoUser:0,verifyPtInfoTime:''};
		$scope.masterEncData={"masterEncData":$scope.newEncounterData};
		
		$scope.initEncounter = function(){
			$('#newEncounter').show();
			$('.sub-encounter-wrapper,en-status-table').perfectScrollbar();
			$('.notespan').perfectScrollbar();
			$('#newEncounter').find('.sel-optn').perfectScrollbar();
			$('#newEncounter').find('.encServicecls').perfectScrollbar();
			
			
			setTimeout(function(){ $('#lftEncounter').find("[ng-init='providerlookup.starFlag = false']").parent().remove(); }, 100);
			
			$('.en-status-popup').hide();
			$('.en-status-click').on('click', function(e) {
				var _that = this;
				$('.en-status-popup').show().animate({}, 100, function() {
					$(this).position({
						of: _that,
						my: 'right bottom',
						at: 'right+230 top-10',
						collision: "flipfit",
					}).animate({
						"opacity": 1
					}, 100);
				});
			});
			$('.close-popup').on('click', function(){
				$('.en-status-popup').hide();
			});
			
			if($scope.masterEncId != '' && $scope.masterEncId != undefined){
				$scope.disabledFacility = true;
				$scope.disabledDept = false;
				$scope.getSubEncdataList($scope.masterEncId);
				$scope.newEncounterData.masterEncId = $scope.masterEncId;
			}
			
			if($scope.bedAreaData != '' && $scope.bedAreaData != undefined){
				$scope.setbedArea($scope.bedAreaData);
			}
			//sample  json {bedAreaData.bedId:'',bedAreaData.bedName:'',bedAreaData.departmentId,bedAreaData.deptName,bedAreaData.unitName,bedAreaData.unitId}
			$scope.newEncounterData.AdmittingProvider  = $scope.AdmittingProvider.provider.Id = global.TrUserId;
			$scope.newEncounterData.AdmittingProviderName= $scope.AdmittingProvider.provider.Name = global.fullUserName;
			$scope.newEncounterData.AttendingProvider = $scope.AdmittingProvider.provider.Id = global.TrUserId;
			$scope.newEncounterData.AttendingProviderName =  $scope.AdmittingProvider.provider.Name = global.fullUserName;
		};
		
		 $scope.openObservPopup = function(e){
		        var _that = angular.element(e.target);
		        angular.element('.observation-popup').show().animate({}, 100, function() {
		            angular.element('.observation-popup').position({
		                of: _that,
		                my: 'center top',
		                at: 'center top+30',
		                collision: "flipfit",
		            })
		        });
		        e.stopPropagation();
		    };
		
		    $scope.closeObserv = function(){
		        $('.observation-popup').hide();
		    }

		$scope.setbedArea = function(){
			var AreaData = angular.copy($scope.bedAreaData);
			if(AreaData.bedName != null && AreaData.bedName != undefined && AreaData.bedName != '' ){
				$scope.newEncounterData.bed = AreaData.bedId;
				$scope.selectedBed.bedId = AreaData.bedId;
				$scope.selectedBed.bedName = AreaData.bedName;	
			}
			if(AreaData.deptName != null && AreaData.deptName != undefined && AreaData.deptName != '' ){
				$scope.selectedDept.deptName = AreaData.deptName;
				$scope.selectedDept.departmentId = AreaData.departmentId;
				$scope.newEncounterData.department = AreaData.departmentId;	
			}
			if(AreaData.deptName != null && AreaData.deptName != undefined && AreaData.deptName != ''){
				$scope.selectedUnit.unitName = AreaData.unitName;
				$scope.selectedUnit.unitId = AreaData.unitId;
				$scope.newEncounterData.unit = AreaData.unitId;	
			}
			if(AreaData.facilityName != null && AreaData.facilityName != undefined && AreaData.facilityName != ''){
				$scope.setFacility = true;
				$scope.newEncounterData.facility = AreaData.facilityId;
				$scope.selFacility.facility.Id = AreaData.facilityId;
				$scope.newEncounterData.facilityName = AreaData.facilityName;
				$scope.selFacility.facility.Name = AreaData.facilityName;
			}
			$scope.setBedData = true;
		}
		
		$scope.cancelEncounter = function(){
			$("#newEncounter").modal('hide');
			$modalInstance.close("closed");
			$modalInstance.dismiss();
			if($scope.calledFrom == 'EncounterModal'){
				$("#encounterModal").modal('hide');
			}
			if(!$scope.openAsModalDialog){
			//$scope.getEncList();
		}
		}
		
		$scope.setMomentEncStatus = function(){
	    	for(var i=0;i<$scope.newEncounterData.encounterStatus.length;i++ ){
	    		if($scope.newEncounterData.encounterStatus[i].dateAndTime != ''){
	    			$scope.newEncounterData.encounterStatus[i].encMomentDate = moment($scope.newEncounterData.encounterStatus[i].dateAndTime, "MM/DD/YYYY HH:mm:ss");	
	    		}else{
	    			$scope.newEncounterData.encounterStatus[i].encMomentDate ='';
	    		}
	    		
	    	}
	    }
		$scope.getSubEncdataList = function(masterEncId) {
			var subEncData = {
					'masterEncId':masterEncId
			};
			newApptService.getSubEncDataList(subEncData).success(function(response){
				subEncRecvData = response;
				if(response != null && response != undefined && response.length>0){
					for (var i=0;i<subEncRecvData.length;i++)
					{
						$scope.subEncData = {};
						if($scope.disabledFacility == true){
							$scope.selFacility.facility.Id = subEncRecvData[0].facilityId;
							$scope.newEncounterData.facilityName = subEncRecvData[0].facilityName;
							$scope.selFacility.facility.Name = subEncRecvData[0].facilityName;
							$scope.newEncounterData.facility = subEncRecvData[0].facilityId;
							$scope.disabledDept = false;
						}
						$scope.subEncData.encSelectedEncStatusDate = subEncRecvData[i].encDateStatus;
						$scope.subEncData.encStatusPatientType = subEncRecvData[i].encStatusPatientType;
						$scope.subEncData.providerName = subEncRecvData[i].providerName;
						$scope.subEncData.facilityName = subEncRecvData[i].facilityName;
						$scope.subEncData.serviceTypeName = subEncRecvData[i].serviceTypeName;
						$scope.subEncData.encounterId = subEncRecvData[i].encounterId;
						$scope.subEncDataList[subEncRecvData[i].encounterId]=$scope.subEncData;
						$scope.newEncounterData.masterEncAdmitDateTime = subEncRecvData[i].masterEncDate;
						$scope.momentMasterAdmitDate = '';
						$scope.momentMasterAdmitDate = '';
						$scope.newEncounterData.ptInfoVerified = subEncRecvData[i].ptInfoVerified;
						$scope.momentMasterAdmitDate = moment(subEncRecvData[i].masterEncDate, "MM/DD/YYYY HH:mm:ss");
						$scope.newEncounterData.masterEncDischargeDateTime = subEncRecvData[i].masterEncStopDate;
						$scope.momentMasterDischargeDate = '';
						$scope.momentMasterDischargeDate = moment($scope.newEncounterData.masterEncDischargeDateTime, "MM/DD/YYYY HH:mm:ss");
						if(null != $scope.subEncDataList ){
				    		$scope.subEncCount='('+Object.keys($scope.subEncDataList).length+')';
				    	}else{
				    		$scope.subEncCount = '(0)';
				    	}
					}
					if($scope.subEncId != '' && $scope.subEncId != undefined){
						$scope.setSelectedSubEnc($scope.subEncId);
						$scope.newEncounterData.subEncId = $scope.subEncId;
					}
		
				}else{
		
				}
			})
			.error(function(e) {
				console.log('error '+e);
			});
		}
		$scope.setCurrentDate = function(index){
			$scope.newEncounterData.encounterStatus[index].dateAndTime = getDateTime();
			$scope.newEncounterData.encounterStatus[index].user =  $scope.userFullName  ;
			$scope.newEncounterData.encounterStatus[index].nUserId = global.TrUserId;
			$scope.newEncounterData.encounterStatus[index].encMomentDate = moment(getDateTime(), "MM/DD/YYYY HH:mm:ss");
			
		};
		$scope.resetCurrentDate = function(index){
			$scope.newEncounterData.encounterStatus[index].dateAndTime = '';
			$scope.newEncounterData.encounterStatus[index].user =  '' ;
			$scope.newEncounterData.encounterStatus[index].encMomentDate = '';
			$scope.newEncounterData.encounterStatus[index].nUserId = '';
			$scope.newEncounterData.encounterStatus[index].status = '';
		};
		$scope.resetObrDate = function(type){
			if(type == 'endDate'){
				$scope.newEncounterData.obrEnddate = '';
				$scope.newEncounterData.obrEndUserId=0;
				$scope.obrUser.endUser='';
				$scope.momentObrEndDate='';
			}else if(type == 'startDate'){
				$scope.newEncounterData.obrStartdate = '';
				$scope.newEncounterData.obrStartUserId=0;
				$scope.obrUser.startUser = '';
				$scope.momentObrStartDate = '';
			}
		};
		
		$scope.setObrUser = function(type){
			if(type == 'EndUser'){
				$scope.newEncounterData.obrEndUserId=global.TrUserId;
				$scope.obrUser.endUser = $scope.userFullName;
				if($scope.momentObrEndDate instanceof  moment){
					$scope.newEncounterData.obrEnddate = $scope.momentObrEndDate.format("MM/DD/YYYY HH:mm:ss");
				}
			}else if(type == 'StartUser'){
				$scope.newEncounterData.obrStartUserId=global.TrUserId;
				$scope.obrUser.startUser = $scope.userFullName;
				if($scope.momentObrStartDate instanceof  moment){
					$scope.newEncounterData.obrStartdate = $scope.momentObrStartDate.format("MM/DD/YYYY HH:mm:ss");
				}
			}
		};
		
		
		
		$scope.setApptStatusUsername=function(encStatus){
			encStatus.user = $scope.userFullName ;
			if(encStatus.encMomentDate instanceof  moment){
	    		encStatus.dateAndTime   = encStatus.encMomentDate.format('YYYY-MM-DD HH:mm:ss');
	    	}
		};
		
		if($scope.masterEncId == undefined || $scope.masterEncId == ''){
			$scope.newEncounterData.masterEncAdmitDateTime = getDateTime();
			$scope.momentMasterAdmitDate = moment($scope.newEncounterData.masterEncAdmitDateTime, "MM/DD/YYYY HH:mm:ss");
		}
		if($scope.selectedPatient!=undefined){
			$scope.newEncounterData.patientid = $scope.selectedPatient.ptId;
			if($scope.newEncounterData.patientid == undefined){
				$scope.newEncounterData.patientid = $scope.selectedPatient.PtId;
			}
			if($scope.selectedPatient.ptGender!= ''){
				if($scope.selectedPatient.ptGender == 'male'){
					$scope.patientGender = 'M';	
				}else if($scope.selectedPatient.ptGender == 'female'){
					$scope.patientGender = 'F';
				}
				 	
			}
		}
		
		$scope.newEncounterData.encDateTime = getDateTime();
		$scope.momentMasterEncounterDate  = moment($scope.newEncounterData.encDateTime, "MM/DD/YYYY HH:mm:ss");
		
		
		var params = {
				'encounterId':'',
				'loggedInUserId':global.TrUserId
		};
		
		newApptService.getEncounterStatus(params).success(function(response){
			if(response != null && response != undefined ){
				$scope.newEncounterData.encounterStatus= response.encStatus;
				$scope.setMomentEncStatus();
				$scope.obrPtType = response.obrPtType;
				$scope.EncMappedData = JSON.parse(response.encMappingData);
				$scope.roomType = JSON.parse(response.roomType);
				$scope.userFullName = response.userFullName;
				$scope.setMapData();
				if($scope.setFacility != true){
					$scope.newEncounterData.facility = response.DefaultFacility.facilityId;
					$scope.newEncounterData.facilityName= response.DefaultFacility.Name;
					$scope.selFacility.facility.Id = response.DefaultFacility.facilityId;
					$scope.selFacility.facility.Name =response.DefaultFacility.Name;	
				}
				$scope.setDefaultStatus();
			}else{
				$scope.newEncounterData.encounterStatus = [];
				$scope.EncMappedData = "";
				$scope.roomType = [];
			}
		})
		.error(function() {
			//(503 == data.statusCode) ? showIPMessage(data.errorMsg, '', 'ErrorMsg') : '';
		});
		if($scope.defaultInpatientFlag == true || $scope.defaultOutPatientFlag == true){
			if($scope.defaultOutPatientFlag){
				$scope.newEncounterData.encounterType = 'OUTPATIENT';	
			}else if($scope.defaultInpatientFlag){
				$scope.newEncounterData.encounterType = 'INPATIENT';
			}
		}
			$scope.setMapData = function(){
				if(null != $scope.EncMappedData && $scope.EncMappedData != ''){
					$scope.encPatientType = 	$scope.EncMappedData.encounterType[$scope.newEncounterData.encounterType];
					$('#newEncounter').find('#ptTypeList').css('max-height','150px');
					$('#newEncounter').find('#ptTypeList').perfectScrollbar();
				}
		};
		$scope.setDefaultStatus = function() {
			for(var i=0;i<$scope.newEncounterData.encounterStatus.length;i++){
				if($scope.newEncounterData.encounterStatus[i].default== true ){
					$scope.setEncounterStatus($scope.newEncounterData.encounterStatus[i].nStatusId,$scope.newEncounterData.encounterStatus[i].status,$scope.newEncounterData.encounterStatus[i].dateAndTime,i);
					 $scope.setEncounterSelectedId();
				}else if($scope.newEncounterData.encounterStatus[i].reschedule== true){
					$scope.ResceduledRequestStatusId = $scope.newEncounterData.encounterStatus[i].nStatusId;
	    		}else if($scope.newEncounterData.encounterStatus[i].rescheduled== true){
	    			$scope.ResceduledStatusId = $scope.newEncounterData.encounterStatus[i].nStatusId;
	    		}else if($scope.newEncounterData.encounterStatus[i].canceled== true){
	    			$scope.CancelStatusId  = $scope.newEncounterData.encounterStatus[i].nStatusId;
	    		}else if($scope.newEncounterData.encounterStatus[i].fullReg== true){
	    			$scope.FullReg  = $scope.newEncounterData.encounterStatus[i].nStatusId;
	    		}	
				}
		};
		
		$scope.setServiceType = function(serviceTypeId,serviceTypeValue) {
			$scope.newEncounterData.serviceType = serviceTypeId;
			$scope.ServiceTypeValue = serviceTypeValue;
			$scope.newEncounterData.serviceTypeName  =serviceTypeValue;
			$scope.DisplayDataJson.serviceType  =serviceTypeValue;
			$scope.newEncounterData.setSelectedStatusName =[]; 
			$scope.DisplayDataJson.selectedServiceType = "";
			$scope.getSerDeptMapping('Service');
			for(var i=0;i<$scope.servicenameDiagnosisMapping.length;i++){
				if($scope.servicenameDiagnosisMapping[i].serviceAction == 'Inserted'){
					$scope.servicenameDiagnosisMapping[i].serviceAction = 'Delete';	
				}else if($scope.servicenameDiagnosisMapping[i].serviceAction == 'Insert'){
					$scope.servicenameDiagnosisMapping.splice(i,1);
				}
				
			}
			var obj = {'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]};
			$scope.servicenameDiagnosisMapping.push(obj);
			$scope.getServiceNameServiceModal('Search');
			
		}
		$scope.selectServiceType = function(){
			$scope.SerNameMandate = false;
			$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.patientType,"patientType","select");
			$scope.alertmsg = " Please select Patient Type ";	
			if($scope.dirty_flag == true){
				return $scope.dirty_flag;	
			}
			
			$scope.getServiceType();
		}
		$scope.selectPatientType = function(){
			$scope.SerNameMandate = false;
			$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.encounterType,"encTyperadio","radio");
			$scope.alertmsg = " Please select Encounter Type  ";
			return $scope.dirty_flag;
		}
		$scope.changePatientType = function(encType) {
				$scope.radionButtonClass ="";
				$scope.encPatientType  = $scope.EncMappedData.encounterType[encType];
				$scope.DisplayDataJson.patientType = 'Select';
				$scope.DisplayDataJson.serviceType  ='Select';
				$scope.encServiceType = '';
				resetServiceType();
		}
		function resetServiceType(){
			$scope.newEncounterData.serviceType = '';
			$scope.ServiceTypeValue = '';
			$scope.newEncounterData.serviceTypeName  ='';
			$scope.DisplayDataJson.serviceType  ='Select';
			$scope.newEncounterData.setSelectedStatusName =[]; 
			$scope.DisplayDataJson.selectedServiceType = "";
			$scope.getSerDeptMapping('Service');
			for(var i=0;i<$scope.servicenameDiagnosisMapping.length;i++){
				if($scope.servicenameDiagnosisMapping[i].serviceAction == 'Inserted'){
					$scope.servicenameDiagnosisMapping[i].serviceAction = 'Delete';	
				}else if($scope.servicenameDiagnosisMapping[i].serviceAction == 'Insert'){
					$scope.servicenameDiagnosisMapping.splice(i,1);
				}
				
			}
			var obj = {'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]};
			$scope.servicenameDiagnosisMapping.push(obj);
			$scope.getServiceNameServiceModal('Search');
		}
		
		$scope.setPatientType = function(ptTypeid,ptTypeValue) {
			$scope.DisplayDataJson.serviceType  ='Select';
			$scope.newEncounterData.patientType = ptTypeid;
			$scope.newEncounterData.serviceType = '';
			$scope.DisplayDataJson.patientType = ptTypeValue;
			$scope.disableObrPtType = true;
			$scope.newEncounterData.obrStartdate = '';
			$scope.newEncounterData.obrEnddate = '';
			$scope.newEncounterData.obrEndUserId = 0;
			$scope.newEncounterData.obrStartUserId = 0;
			$scope.obrUser.startUser = '';
			$scope.obrUser.endUser = '';
			getObrPtType(ptTypeid);
			resetServiceType();
		}
		
		$scope.getServiceType = function(){
			var jsonObj = {
					'deptId': $scope.selectedDept.departmentId,
					'patientType':$scope.newEncounterData.patientType,
			}
			
			if($scope.selectedDept.departmentId == undefined || $scope.selectedDept.departmentId == 0){
				$scope.dirty_flag = true;
				$scope.alertmsg = " Please select Department  ";
				return false;
			}
			newApptService.getServiceTypeList(jsonObj).success(function(response){
				if(response != null && response != undefined ){
					$scope.encServiceType = response;
					$('#newEncounter').find('#lstServiceType').perfectScrollbar();
				}else{
					$scope.encServiceType = {};
				}
			}).error(function(e) {
				console.log('error '+e);
			});
		}
		$scope.admissionType = function($admissionEvent) {
			$scope.newEncounterData.admissionType = $admissionEvent.target.value;
			$scope.DisplayDataJson.admissionType = $admissionEvent.target.innerText;
		}
		$scope.admissionSource = function($admissionSourceEvent) {
			$scope.newEncounterData.admissionSource = $admissionSourceEvent.target.value;
			$scope.DisplayDataJson.admissionSource = $admissionSourceEvent.target.innerText;
		}
		$scope.methodOfArrival = function($methodOfArrivalEvent) {
			$scope.newEncounterData.methodOfArrival = $methodOfArrivalEvent.target.value;
			$scope.DisplayDataJson.methodOfArrival = $methodOfArrivalEvent.target.innerText;
			
		}
		$scope.ESIAcuity = function($acuityEvent) {
			$scope.newEncounterData.esiAcuity = $acuityEvent.target.value;
			$scope.DisplayDataJson.EsiAcuity = $acuityEvent.target.innerText;
		}
		$scope.visitRegion = function($visitRegionEvent) {
			$scope.newEncounterData.statedVisitRegion = $visitRegionEvent.target.value;
		}
		$scope.diagnosis = function($diagnosisEvent) {
			$scope.newEncounterData.diagnosis = $diagnosisEvent.target.value;
		}
		
		$scope.LevelOfCare = function($levelOfCareEvent) {
			$scope.newEncounterData.LevelOfCare = $levelOfCareEvent.target.value;
		}
		
		function setEncUnitObj(unitObj){
			$scope.newEncounterData.unit=unitObj.unitId;
		}
		
		$scope.setResetDept=function(){
			$scope.currentLocation = '';
			$scope.newEncounterData.department = '0';
			$scope.selectedDept = {};
			$scope.setResetUnit();
		}
		
		$scope.setResetUnit=function(){
			$scope.newEncounterData.unit = '0';
			$scope.selectedUnit = {};
			$scope.setResetBed();
		}
		$scope.setResetBed=function(){
			setCurrentLocation('unit');
			$scope.selectedBed = {};
			$scope.newEncounterData.bed='0';
		}
		$scope.setBed=function(){
			setCurrentLocation('bed');
		}
		function setCurrentLocation(type){
			$timeout(function(){
				 if($scope.selectedDept.deptName != '' && $scope.selectedDept.deptName != undefined){
						$scope.currentLocation = $scope.selectedDept.deptName;
				 }
				if($scope.selectedUnit.unitName != '' && $scope.selectedUnit.unitName != undefined)
				{
					$scope.currentLocation += '/'+$scope.selectedUnit.unitName;
				}
				if($scope.selectedBed.bedName != '' && $scope.selectedBed.bedName != undefined){
					$scope.currentLocation += '/'+$scope.selectedBed.bedName;
				}
				},300);
		}
		$scope.setEncBedObject = function(){
			$scope.newEncounterData.bed  = $scope.selectedBed.bedId;
			$scope.newEncounterData.department  = $scope.selectedDept.departmentId;
			$scope.newEncounterData.unit  = $scope.selectedUnit.unitId;
			$scope.newEncounterData.deptDescipline = $scope.selectedDept.disciplineName ;
			
		}
		$scope.SelectedProvider = function() {
			$scope.newEncounterData.AdmittingProvider  = $scope.AdmittingProvider.provider.Id;
			$scope.newEncounterData.AdmittingProviderName= $scope.AdmittingProvider.provider.Name;
		}
		$scope.SelectedAttendingProvider = function() {
			$scope.newEncounterData.AttendingProvider  = $scope.AttendingProvider.provider.Id;
			$scope.newEncounterData.AttendingProviderName= $scope.AttendingProvider.provider.Name;
		}
		$scope.getFacilityInfo = function(selectedFacility) {
			if(selectedFacility.facilityId !=undefined){
				$scope.newEncounterData.facility  = selectedFacility.facilityId;
				$scope.newEncounterData.facilityName= selectedFacility.facilityName;
				$scope.disabledDept = false;
			}else{
				$scope.disabledDept = true;
			}
			
			$scope.encServiceType = {};
			$scope.DisplayDataJson.serviceType = 'Select';
			$scope.disabledUnitBed = true;
			$scope.setResetDept();
			resetServiceType();
		}
		$scope.setRoomType =function(id,name){
			$scope.newEncounterData.roomType  = id;
			$scope.DisplayDataJson.roomTypeName = name;
		}
		
		$scope.setSelectedSubEnc = function(subEncId) {
			if(null != $scope.subEncDataList){
				var subEncArrayId = '';
					$.each($scope.subEncDataList, function(key, value){
					subEncArrayId = key ;
					if(subEncArrayId ==  subEncId){
						$scope.subEncDataList[key].itemseleted = true;
					}else{
						$scope.subEncDataList[key].itemseleted = false;
					}
				
			});
		}
			var subEncData = {
					'subEncounterId':subEncId
			};
			newApptService.getSubEncDetail(subEncData).success(function(response){
				if(response != null && response != undefined && response.length>0){
					$scope.setEncounterData= eval(response);
				}else{
					$scope.setEncounterData = [{}];
				}
				$scope.displaySubEncData($scope.setEncounterData);
			})
			.error(function(e) {
				console.log('error '+e);
			});
			
		}
		
		
		
		
		$scope.displaySubEncData = function(subEncDataDetails) {
			$scope.EditEnc = true;
			$scope.newEncounterData.isNewPatient = subEncDataDetails[0].newPatient;
			$scope.newEncounterData.transitionOfCare = subEncDataDetails[0].transitionOfCare;
			$scope.newEncounterData.isConfidentialEnc = subEncDataDetails[0].confidential;
			$scope.newEncounterData.encounterType = subEncDataDetails[0].encType;
			$scope.newEncounterData.transitionOfCare = subEncDataDetails[0].transitionOfCare;
			$scope.newEncounterData.isConfidentialEnc = subEncDataDetails[0].confidential;
			$scope.newEncounterData.patientType = subEncDataDetails[0].patientType;
			getObrPtType($scope.newEncounterData.patientType);
			$scope.newEncounterData.serviceType = subEncDataDetails[0].serviceType;
			$scope.newEncounterData.admissionType = subEncDataDetails[0].admissionType;
			$scope.newEncounterData.admissionSource = subEncDataDetails[0].admissionSource;
			$scope.newEncounterData.methodOfArrival = subEncDataDetails[0].methodOfArr;
			$scope.newEncounterData.esiAcuity = subEncDataDetails[0].esiAcuity;
			$scope.newEncounterData.subEncId = subEncDataDetails[0].encounterId;
			$scope.newEncounterData.encounterStatus = subEncDataDetails[0].encounterStatusDetail;
			$scope.setMomentEncStatus();
			$scope.DisplayDataJson.patientType = subEncDataDetails[0].patientTypeValue;
			$scope.DisplayDataJson.serviceType = subEncDataDetails[0].serviceTypeValue;
			$scope.DisplayDataJson.admissionType = subEncDataDetails[0].admissionTypeValue;
			$scope.DisplayDataJson.admissionSource = subEncDataDetails[0].admissionSourceValue;
			$scope.DisplayDataJson.methodOfArrival = subEncDataDetails[0].methodOfArrValue;
			if(subEncDataDetails[0].esiacuityValue == undefined || subEncDataDetails[0].esiacuityValue == ''){
				$scope.DisplayDataJson.EsiAcuity = 'Select';
			}else{
				$scope.DisplayDataJson.EsiAcuity = subEncDataDetails[0].esiacuityValue;	
			}
			
			if(subEncDataDetails[0].doctorid == '0' || subEncDataDetails[0].doctorid == '' || subEncDataDetails[0].doctorid == 0){
				$scope.newEncounterData.AdmittingProvider  = $scope.AdmittingProvider.provider.Id = global.TrUserId;
				$scope.newEncounterData.AdmittingProviderName= $scope.AdmittingProvider.provider.Name = global.fullUserName;
			}else{
				$scope.newEncounterData.AdmittingProvider  = $scope.AdmittingProvider.provider.Id = subEncDataDetails[0].doctorid;
				$scope.newEncounterData.AdmittingProviderName =$scope.AdmittingProvider.provider.Name = subEncDataDetails[0].providerName;	
			}
			$scope.newEncounterData.statedVisitRegion = subEncDataDetails[0].reason;
			$scope.newEncounterData.encounterSelectedStatusId = subEncDataDetails[0].encounterStatus;
			if($scope.ResceduledStatusId == $scope.newEncounterData.encounterSelectedStatusId || $scope.FullReg == $scope.newEncounterData.encounterSelectedStatusId || $scope.CancelStatusId == $scope.newEncounterData.encounterSelectedStatusId){
				$scope.EncounterResceduled = true;
			}else{
				$scope.EncounterResceduled = false;
			}
			$scope.newEncounterData.encounterSelectedStatus = subEncDataDetails[0].encounterStatusValue;
			$scope.newEncounterData.encDateTime =subEncDataDetails[0].encounterDate;
			$scope.momentMasterEncounterDate = '';
			var encDate = angular.copy($scope.newEncounterData.encDateTime);
			$scope.momentMasterEncounterDate  = moment(encDate, "MM/DD/YYYY HH:mm:ss");
			$scope.AttendingProvider.provider.Name = subEncDataDetails[0].attendingProviderName;
			$scope.AttendingProvider.provider.Id = subEncDataDetails[0].attendingProviderId;
			$scope.newEncounterData.AttendingProvider = subEncDataDetails[0].attendingProviderId;
			$scope.newEncounterData.facility  = subEncDataDetails[0].facilityId;
			$scope.disabledDept = false;
			$scope.disabledUnitBed = false;
			$scope.selFacility.facility.Id = subEncDataDetails[0].facilityId;
			$scope.selFacility.facility.Name = subEncDataDetails[0].facilityName;
			$scope.newEncounterData.facilityName = subEncDataDetails[0].facilityName;
			$scope.newEncounterData.serviceTypeName = subEncDataDetails[0].serviceTypeValue;
			$scope.newEncounterData.diagnosis = [];
			$scope.DisplayDataJson.selectedDignosisList = '';
			$scope.newEncounterData.diagnosisChanged='';
			$scope.selectedDept.deptName = subEncDataDetails[0].lstBedData[0].deptName;
			$scope.selectedDept.departmentId = subEncDataDetails[0].lstBedData[0].departmentId;
			$scope.selectedDept.disciplineName = subEncDataDetails[0].lstBedData[0].disciplineName;
			$scope.newEncounterData.department = subEncDataDetails[0].lstBedData[0].departmentId;
			$scope.newEncounterData.roomType = subEncDataDetails[0].roomtype;
			$scope.selectedUnit.unitName = subEncDataDetails[0].lstBedData[0].unitName;
			$scope.selectedUnit.unitId = subEncDataDetails[0].lstBedData[0].unitId;
			$scope.newEncounterData.unit = subEncDataDetails[0].lstBedData[0].unitId;
			$scope.selectedBed.bedId = subEncDataDetails[0].lstBedData[0].bedId;
			$scope.selectedBed.bedName = subEncDataDetails[0].lstBedData[0].bedName;
			$scope.newEncounterData.bed = subEncDataDetails[0].lstBedData[0].bedId;
			$scope.newEncounterData.obrStartdate = subEncDataDetails[0].obrStartDate;
			$scope.newEncounterData.obrEnddate = subEncDataDetails[0].obrEndDate;
			$scope.momentObrStartDate = moment($scope.newEncounterData.obrStartdate, "MM/DD/YYYY HH:mm");
			$scope.momentObrEndDate = moment($scope.newEncounterData.obrEnddate , "MM/DD/YYYY HH:mm");	
			$scope.newEncounterData.obrEndUserId = subEncDataDetails[0].obrEndUid;
			$scope.newEncounterData.obrStartUserId = subEncDataDetails[0].obrStartUid;
			$scope.obrUser.startUser = subEncDataDetails[0].obrStartUser;
			$scope.obrUser.endUser = subEncDataDetails[0].obrEndUser;
			$scope.newEncounterData.encNoteList = JSON.parse(subEncDataDetails[0].note);
			if(subEncDataDetails[0].appointment == true){
				$scope.newEncounterData.isAppointment = true;	
			}else{
				$scope.newEncounterData.isAppointment = false;
			}
			
			
			$scope.currentLocation = subEncDataDetails[0].lstBedData[0].deptName;
			if($scope.selectedUnit.unitName != '' && $scope.selectedUnit.unitName != undefined){
				$scope.currentLocation += '/'+$scope.selectedUnit.unitName;
			}
			if($scope.selectedBed.bedName != '' && $scope.selectedBed.bedName != undefined){
				$scope.currentLocation += '/'+$scope.selectedBed.bedName;
			}
			
			$scope.servicenameDiagnosisMapping = JSON.parse(subEncDataDetails[0].servicenameDxmapping);
			if($scope.servicenameDiagnosisMapping.length == 0){
				$scope.servicenameDiagnosisMapping = [{'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]}];				
			}
			
			if($scope.newEncounterData.encounterType == 1 ){
				$scope.newEncounterData.encounterType = 'INPATIENT';
			}else if($scope.newEncounterData.encounterType == 2 ){
				$scope.newEncounterData.encounterType = 'OUTPATIENT';
			}
			$scope.encPatientType  = $scope.EncMappedData.encounterType[$scope.newEncounterData.encounterType];
			$scope.encServiceType = $scope.EncMappedData.serviceType[$scope.DisplayDataJson.patientType];
			$scope.newEncounterData.setSelectedStatusName = subEncDataDetails[0].oSeviceObj;
			$scope.DisplayDataJson.roomTypeName = 'Select';
			for(var i=0;i<$scope.roomType.length;i++){
				if($scope.roomType[i].accomodationId == $scope.newEncounterData.roomType){
					$scope.DisplayDataJson.roomTypeName =$scope.roomType[i].accName;
					break;
				}
			}
			$scope.getServiceNameServiceModal('Search');
		}
		
		$scope.setEncounterStatus = function(selectedEncStatusId,selectedEncStatusName,selectedEncStatusDate,index){
	    	$scope.selectedEncStatusId = selectedEncStatusId;
	    	$scope.selectedEncStatusName = selectedEncStatusName;
	    	$scope.setCurrentDate(index);
	    	$scope.selectedEncStatusDate = getDateTime();
	    };
	    $scope.addNoteNotch = function(event){
	        $(event.target).toggleClass('active');
	        var bottompanel = $('.note-secarea');
	        if (bottompanel.hasClass('visible')) {
	            bottompanel.animate({
	                "bottom": "-143px"
	            }, "2000").removeClass('visible');
	        } else {
	            bottompanel.animate({
	                "bottom": "0"
	            }, "2000").addClass('visible');
	        }
	   };
	   
	   $scope.addNotes = function(noteTxt){
	        if(noteTxt){
	        	$scope.newEncounterData.encNoteList.push({
	        		"noteId":0,
	                "name":$scope.userFullName,
	                "timestamp":getDateTime(),
	                "userId":global.TrUserId,
	                "noteText":noteTxt
	            });
	            
	            $scope.appontmentText = '';
	        }
	        
	    };
	    $scope.setEncounterSelectedId = function(){
	    	
	    	if($scope.selectedEncStatusName != '' && $scope.selectedEncStatusName != undefined){
	    		$scope.newEncounterData.encounterSelectedStatusId = $scope.selectedEncStatusId;
		    	$scope.newEncounterData.encounterSelectedStatus = $scope.selectedEncStatusName;
		    	$scope.newEncounterData.selectedEncStatusDate = $scope.selectedEncStatusDate;	
	    	}
	    	
	    };
	    
	    $scope.setSelectedDignosisList = function (DignosisList) {
	    	$scope.DisplayDataJson.selectedDignosisList = "";
	    	 for (var i=0;i<DignosisList.length;i++)
	        {
	           $scope.DisplayDataJson.selectedDignosisList  = $scope.DisplayDataJson.selectedDignosisList +DignosisList[i].itemName +'; ';
	        }
	    };
	    $scope.setSelectedServiceName = function (serviceNameList) {
	    	$scope.DisplayDataJson.selectedServiceType = "";
	    	 for (var i=0;i<serviceNameList.length;i++)
	        {
	           $scope.DisplayDataJson.selectedServiceType  = $scope.DisplayDataJson.selectedServiceType +serviceNameList[i].serviceName +'; ';
	        }
	    };
	    
	    $scope.setSubEncounterData = function(subEncRecvData){
	    	var subEncData = {encStatus:'',encSelectedEncStatusDate:'',encServiceType:'',providerName:'',facilityName:'',serviceTypeName:'',encounterId:''};
	    	subEncData.encStatus = $scope.newEncounterData.encounterSelectedStatus;
	    	subEncData.encSelectedEncStatusDate = $scope.newEncounterData.encDateTime;
	    	subEncData.encStatusPatientType = $scope.newEncounterData.encounterSelectedStatus+"-"+$scope.DisplayDataJson.patientType
	    	subEncData.providerName = $scope.newEncounterData.AdmittingProviderName;
	    	subEncData.facilityName = $scope.newEncounterData.facilityName;
	    	subEncData.serviceTypeName = $scope.newEncounterData.serviceTypeName;
	    	subEncData.encounterId = subEncRecvData[0].masterSubEncId;
	    	$scope.newEncounterData.masterEncId = subEncRecvData[0].masterEncId;
	    	$scope.masterEncId = subEncRecvData[0].masterEncId;
	    	$scope.newEncounterData.subEncId = subEncRecvData[0].masterSubEncId;
	    	$scope.subEncDataList[$scope.newEncounterData.subEncId]=subEncData;
	    	if(null != $scope.subEncDataList ){
	    		$scope.subEncCount='('+Object.keys($scope.subEncDataList).length+')';
	    	}else{
	    		$scope.subEncCount = '(0)';
	    	}
	    	$scope.ResetEncSetting();
	    	
	    };
	    
	    $scope.validateEncData = function(){
	    	$scope.id="";
	    	$scope.validationFlag=false;
	    	$scope.radionButtonClass = "";
	    	

	    	if($scope.momentMasterAdmitDate != null && $scope.momentMasterAdmitDate instanceof  moment){
	    		$scope.newEncounterData.masterEncAdmitDateTime  = $scope.momentMasterAdmitDate.format('MM/DD/YYYY HH:mm:ss');
	    		if($scope.newEncounterData.masterEncAdmitDateTime  == "Invalid date"){
	    			$scope.newEncounterData.masterEncAdmitDateTime = '';
	    		}
	    	}
	    	if($scope.momentMasterDischargeDate != null && $scope.momentMasterDischargeDate instanceof  moment){
	    		$scope.newEncounterData.masterEncDischargeDateTime  = $scope.momentMasterDischargeDate.format('MM/DD/YYYY HH:mm:ss');
	    	}if($scope.newEncounterData.masterEncDischargeDateTime  == "Invalid date"){
	    		$scope.newEncounterData.masterEncDischargeDateTime = '';
	    	}
	    	if($scope.momentMasterEncounterDate != null && $scope.momentMasterEncounterDate instanceof  moment){
	    		$scope.newEncounterData.encDateTime  = $scope.momentMasterEncounterDate.format('MM/DD/YYYY HH:mm:ss');
	    	}
	    		$scope.mandatoryFieldName = "Enter Admit Date & Time ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.masterEncAdmitDateTime,"admitStartDate","Date");
	    		if(!$scope.dirty_flag){
	        		$scope.mandatoryFieldName = " Select Encounter Type ";
	        		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.encounterType,"encTyperadio","radio");
	        		$scope.radionButtonClass = "validdata";
	        		if(!$scope.dirty_flag){
	        			$scope.radionButtonClass ="";
	        		}
	        	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Encounter Status ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.encounterSelectedStatus,"encounterStatus","text");
	    		
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select  Patient Type ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.patientType,"patientType","select");
	    		
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Service Type ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.serviceType,"serviceType","select");
	    		
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Admission Type ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.admissionType,"admissionType","select");
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Admission Source ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.admissionSource,"admissionSource","select");
	    	}
	    	
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Admitting Provider ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.AdmittingProviderName,"admittingProvider","select");
	    	}
	    	if(!$scope.dirty_flag){
	    		if($scope.SerNameMandate){
	    			$scope.mandatoryFieldName = " Select ServiceName  ";
		    		$scope.dirty_flag = $scope.CheckField($scope.servicenameDiagnosisMapping,"divServiceName","serviceName");	
	    		}
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Facility ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.facility,"facilityName","select");
	    	}
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Encounter Date and Time ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.encDateTime,"encDateAndTime","text");
	    		
	    	}
	    	if(!$scope.dirty_flag){
	    		if($scope.SerNameMandate)
	    		$scope.mandatoryFieldName = " Select Encounter Date and Time ";
	    		$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.encDateTime,"encDateAndTime","text");
	    		
	    	}
	    	
	    	if(!$scope.dirty_flag){
	    		$scope.mandatoryFieldName = " Select Department ";
	    		$scope.dirty_flag = $scope.CheckField($scope.selectedDept.deptName,"inlineDepartmentLookup","lookup");
	    	}
	    	
	    	$scope.alertmsg = "Please  "+$scope.mandatoryFieldName; 
	    	if($scope.dirty_flag){
	    		showIPMessage($scope.alertmsg);
	    	}else{
	    		$scope.validationFlag = true;
	    	}
	    		
	    	return $scope.validationFlag;
	     };
	     
	     
	    $scope.clearProviderData= function(type){
		    if('Admit'=== type){
		    	$scope.newEncounterData.AdmittingProvider  = '';
		    	$scope.newEncounterData.AdmittingProviderName= '';	
		    }else if('Attend' == type){
		    	$scope.newEncounterData.AttendingProvider  = '';
				$scope.newEncounterData.AttendingProviderName= '';
		    }
	    }
	     $scope.CheckField= function(param, id, type) {
	    	 
	    	 $scope.isInvalidValid = false;
	    	 if((param  == null || param == undefined  || param == '' )  && type !="lookup"){
	     		$scope.dirty_flag = true;
	     		$scope.isInvalidValid = true;
	     		$('#' + id).addClass('validdata');
	    		$('#' + id).focus();
	     		
	     	}else if((param=='0' || param  == null || param == undefined  || param == '')  && type =="lookup"){
	     		$scope.dirty_flag = true;
	     		$scope.isInvalidValid = true;
	     		$('#' + id).find('input[type=text]').addClass('validdata');
	     	}else if(type == 'serviceName'){
	     		for(var i=0;i<param.length;i++){
	    			if(param[i].serviceAction != 'Delete' ){
	    				if(param[i].serviceid < 1){
	    					$scope.dirty_flag = true;
	    		     		$scope.isInvalidValid = true;
	    		     		$('#' + id).focus();
	    		     		break;
	    				}/*else{
	    					for(var j=0;j<param[i].diagnosisData.length;j++){
	    					if(param[i].diagnosisData[j].itemid==0){
	    						$scope.dirty_flag = true;
		    		     		$scope.isInvalidValid = true;
		    		     		$('#' + id).focus();
		    		     		$scope.mandatoryFieldName = " Select Dx ";
		    		     		break;
	    					}	
	    					}
	    				}*/
	    			}
	    		}
	     	}else{
	     		if(type !="lookup"){
	     		$('#' + id).removeClass('validdata');
	    		$scope.isInvalidValid = false;
	     		}else if(type =="lookup"){
	     			$('#' + id).find('input[type=text]').removeClass('validdata');
	     			$scope.isInvalidValid = false;
	     		}
	     		
	     	}
	    	 return $scope.isInvalidValid;
	    	 
	    };
	    $scope.CreateOrUpdateEnc= function(reqType) {
	    	if($scope.validateEncData()){
	    	var ServiceList = [];
	    	for(var j=0;j<$scope.servicenameDiagnosisMapping.length;j++){
	    		if($scope.servicenameDiagnosisMapping[j].serviceid != 0){
	    			var jsonObj = {
	    					'serviceName':$scope.servicenameDiagnosisMapping[j].serviceName,
	    					'serviceId':$scope.servicenameDiagnosisMapping[j].serviceid,
	    					'deptId':$scope.selectedDept.departmentId
	    			};
	    			ServiceList.push(jsonObj);
	    		}
	    	}
	    		if(ServiceList.length > 0 && $scope.newEncounterData.isAppointment != true){
	    			var jsonList={'serviceList':ServiceList};
	    			newApptService.getServiceNameResourceList(jsonList).success(function(response){
	    				if(response != null && response != undefined ){
	    					if(response.result == true){
	    						$scope.saveEncounterData(reqType);
	    					}else{
	    						jsonList=response.serviceName;
	    						showIPMessage('<strong> <i>'+jsonList+'</i> </strong> cannot be created as it needs a resource to perform. \n Please create an appointment.');
	    					}
	    				}else{

	    				}
	    			}).error(function() {

	    			});
	    		}else{
	    			$scope.saveEncounterData(reqType);
	    		}
	    	}
	    };
	    $scope.saveEncounterData=function(reqType){
	    	$scope.setEncBedObject(); 
	    	$scope.newEncounterData['context'] = $scope.sContext;////TODO : passed context from MS modified by Kaushal on 03/23/2017.Discussed with Azhar/Crystofer this is temporary fix we have to fix this.
	    	$scope.newEncounterData.serviceDiagnosisMap =  $scope.servicenameDiagnosisMapping;
	    	$scope.masterEncData={"masterEncData":$scope.newEncounterData};
	    	if(reqType == 'SaveOk'){
	    		$scope.cancelEncounter();
	    	}
	    	newApptService.saveEncounterData($scope.masterEncData).success(function(response){
	    		if(response != null && response != undefined && response.length>0){
	    			$scope.subEncRecvData = response;
	    			if($scope.callbackEnc!= undefined){
	    				try {
	    					$scope.callbackEnc();
	    				} catch (e) {

	    				}
	    			}
	    		}else{
	    			$scope.subEncData = [];
	    		}
	    		$scope.setSubEncounterData($scope.subEncRecvData);
	    	}).error(function() {

	    	});
	    };
		
		$scope.getdiagnosisData=function(type,code,desc,parentIndex,index){
			var x2js = new X2JS();
			var requestJson = {FormData: createICDXml(type,code,desc,$scope.counter,$scope.pageParam.maxCount)};
			newApptService.getICDList(requestJson).success(function(response){
				$("[class^=dx-search-table-]").removeClass('open');
				if(response != null && response != undefined ){
					var jsonData2 = x2js.xml_str2json(response);
                    $scope.dxDetails = returnDataArray(jsonData2.Envelope.Body.return.ICDCodes.icd);
                    $('.dx-search-table-'+parentIndex+'-'+index).addClass('open');
                }else{
					$scope.dxDetails = {};
				}
			})
			.error(function() {
			});	
		}
		$scope.getDiagnosisList= function(type,code,desc,parentIndex,index){
			$scope.dxDetails={}
			$scope.DiagnosisListJson = {};
			$scope.currentServiceIndex = parentIndex;
			$scope.currentDiagnosisIndex = index;
			$scope.dxType =type;
			$scope.dxCode =code;
			$scope.dxDesc =desc;
			if(type == 'code'){
				$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxDiscreption = '';
			}else{
				$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dx = '';
			}
			$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].itemid = 0;
			var action = $scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxAction;
			if(action == 'Inserted'){
				$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxAction = 'Update';
			}
			$scope.setGetServerData = false;
			$timeout.cancel($scope.setDiagnosisTimeout);
			if(code != '' || desc != ''){
				$scope.setDiagnosisTimeout = $timeout(function() {
					$scope.getdiagnosisData(type,code,desc,parentIndex,index);
			    }, 500);	
			}
		}
		$scope.addSelectedDx = function(dxJson,parentIndex,index){
			for (var i=0;i<$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData.length;i++)
	        {
	           if($scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[i].itemid == parseInt(dxJson.itemId) && $scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[i].dxAction !='Delete'){
	        	   showIPMessage( dxJson.name+'is already selected.', 'AlertMsg');
	        	   return false;
	           }
	        }
			$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dx =dxJson.code;
			$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxDiscreption =dxJson.name;
			$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].itemid =parseInt(dxJson.itemId);
			var action = $scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxAction;
			if(action == 'Inserted'){
				$scope.servicenameDiagnosisMapping[parentIndex].diagnosisData[index].dxAction = 'Update';
			}
			
			$scope.counter = 0;
			$scope.pageParam.pageIndex = 0;
			$scope.pageParam.maxCount = 5;
			$scope.dxType='';
			$scope.dxCode=0;
			$scope.dxDesc='';
			$scope.currentServiceIndex=-1;
			$scope.currentDiagnosisIndex=-1;
		}
		$scope.dxNext = function() {
            if ($scope.dxDetails.length === $scope.pageParam.maxCount) {
                $scope.pageParam.pageIndex = $scope.pageParam.pageIndex + 1;
                $scope.counter = ($scope.pageParam.pageIndex * $scope.pageParam.maxCount) + 1;
                $scope.getdiagnosisData($scope.dxType ,$scope.dxCode,$scope.dxDesc,$scope.currentServiceIndex,$scope.currentDiagnosisIndex);
            }
            
        };

        $scope.dxPrev = function() {
            if ($scope.pageParam.pageIndex !== 0) {
                $scope.pageParam.pageIndex = $scope.pageParam.pageIndex - 1;
                $scope.counter = ($scope.pageParam.pageIndex * $scope.pageParam.maxCount) + 1;
                $scope.getdiagnosisData($scope.dxType ,$scope.dxCode,$scope.dxDesc,$scope.currentServiceIndex,$scope.currentDiagnosisIndex);
            }
        };

		  $scope.addDiagnosisList = function(index){
		        $scope.servicenameDiagnosisMapping[index].diagnosisData.push(
		            {
		            	"dxId":0,
		                "dx":'',
		                "dxDiscreption":'',
		                'itemid':0,
		                'dxAction':'Insert'
		            }
		        )
		        $('.service-detail-scroll').perfectScrollbar();
		    };

		    $scope.addServiceList = function(){
		        $scope.servicenameDiagnosisMapping.push({'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]});
		        $('.service-detail-scroll').perfectScrollbar();
		    };
		    $scope.deleteService = function(index, data){
		    	var bInserted =false;
		    	if(data[index].serviceAction == 'Inserted'){
		    		data[index].serviceAction = 'Delete';	
		    		if(index == 0 && data.length ==1){
		    			 $scope.servicenameDiagnosisMapping.push({'serviceid':-1,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]});
		    		}
		    	}else{
		    		data.splice(index, 1);
		    		var bInsert = true;
		    		for(var i=0;i<data.length;i++){
		    			if(data[i].serviceAction == 'Insert' && bInsert == true){
		    				bInsert = false;	
		    			}else if(data[i].serviceAction == 'Inserted' && bInserted == false){
		    				bInserted = true;
		    			}
		    		}
		    		if(bInsert && !bInserted){
		    			$scope.servicenameDiagnosisMapping.push({'serviceid':-1,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]});	
		    		}
		    	}
		    }
		    $scope.deleteDiagnosisDX = function(index,parentObj){
		    	if(parentObj[index].dxAction == 'Inserted'){
		            parentObj[index].dxAction = 'Delete';
		    	}else{
		    		parentObj.splice(index, 1);	
		    	}
		    }; 
		
		$scope.ResetEncSetting= function() {
			
			$scope.DisplayDataJson.patientType='Select';
			$scope.DisplayDataJson.serviceType='Select';
			$scope.DisplayDataJson.serviceName='Select';
			$scope.DisplayDataJson.admissionType='Select';
			$scope.DisplayDataJson.admissionSource='Select';
			$scope.DisplayDataJson.methodOfArrival='Select';
			$scope.DisplayDataJson.EsiAcuity='Select';
			$scope.DisplayDataJson.roomTypeName='Select';
			$scope.DisplayDataJson.selectedServiceType='';
			$scope.DisplayDataJson.selectedDignosisList='';
			$scope.newEncounterData.subEncId='';
			$scope.newEncounterData.encounterType='';
			$scope.newEncounterData.encounterSelectedStatus='';
			$scope.newEncounterData.selectedEncStatusDate='';
			$scope.newEncounterData.serviceTypeName='Select';
			$scope.newEncounterData.encounterSelectedStatusId='';
			$scope.newEncounterData.diagnosisChanged='';
			$scope.disableproviderlookup = true;
			$scope.SerNameMandate = false;
			$scope.EditEnc = false;
			$scope.dirty_flag = false;
			$scope.newEncounterData.statedVisitRegion='';
			$scope.newEncounterData.esiAcuity='';
			$scope.newEncounterData.serviceName='';
			$scope.newEncounterData.patientType='';
			$scope.newEncounterData.serviceType='';
			$scope.newEncounterData.admissionType='';
			$scope.newEncounterData.admissionSource='';
			$scope.newEncounterData.diagnosis=[];
			$scope.newEncounterData.isConfidentialEnc='';
			$scope.newEncounterData.isNewPatient='';
			$scope.newEncounterData.isAppointment = false;
			$scope.newEncounterData.transitionOfCare='';
			$scope.newEncounterData.encDateTime=getDateTime();
			$scope.momentMasterEncounterDate  = moment($scope.newEncounterData.encDateTime, "MM/DD/YYYY HH:mm:ss");
			$scope.newEncounterData.AdmittingProvider='';
			$scope.newEncounterData.AdmittingProviderName='';
			$scope.newEncounterData.AttendingProvider='';
			$scope.newEncounterData.methodOfArrival='';
			$scope.newEncounterData.department='';
			$scope.newEncounterData.unit='';
			$scope.newEncounterData.bed='0';
			$scope.newEncounterData.roomType='';
			$scope.newEncounterData.LevelOfCare='';
			$scope.newEncounterData.currentLocation='';
			$scope.newEncounterData.setSelectedStatusName=[];
			$scope.newEncounterData.AttendingProviderName = '';
			$scope.encPatientType  = '';
			$scope.encServiceType = '';
			$scope.selectedDept = {};
			$scope.selectedUnit = {};
			$scope.selectedBed = {};
			$scope.newEncounterData.diagnosis =[];
			$scope.setBedData = false;
			$scope.newEncounterData.obrStartdate = '';
			$scope.newEncounterData.obrEnddate = '';
			$scope.newEncounterData.obrEndUserId = 0;
			$scope.newEncounterData.obrStartUserId = 0;
			$scope.momentObrStartDate = '';
			$scope.momentObrEndDate = '';
			$scope.obrUser.startUser = '';
			$scope.obrUser.endUser = '';
			$scope.newEncounterData.encNoteList=[];
			$scope.appontmentText = '';
			$scope.currentLocation = '';
			$scope.disabledDept = true;
			$scope.disabledUnitBed = true;
			$scope.EncounterResceduled = false;
			if($scope.newEncounterData.masterEncId != '' && $scope.newEncounterData.masterEncId != undefined){
				$scope.disabledFacility = true;
				$scope.disabledDept = false;
				
			}
			$scope.newEncounterData.encounterStatus = $scope.resetEncounterStatus($scope.newEncounterData.encounterStatus);
			$scope.servicenameDiagnosisMapping = [{'serviceid':0,'cptcode':'','serviceName' : '','serviceAction':'Insert','diagnosisData':[{'dxId':0,'dx':'','dxDiscreption':'','itemid':0,'dxAction':'Insert'}]}];
			$.each($scope.subEncDataList, function(key, value){
				$scope.subEncDataList[key].itemseleted = false;
			});
			$scope.newEncounterData.encounterType = 'OUTPATIENT';
			if(null != $scope.EncMappedData && $scope.EncMappedData != ''){
				$scope.encPatientType = 	$scope.EncMappedData.encounterType[$scope.newEncounterData.encounterType];
			}
			$scope.disableObrPtType = true;
			
				 $timeout(function() {
					 	$("div[provider-name='AdmittingProvider']" ).find('input:text').val('').addClass('onX').click();
						$("div[provider-name='AttendingProvider']" ).find('input:text').val('').addClass('onX').click();
					}, 0);
			
			};
			$scope.EncounterDiagnosisModal = function(){
				$ocLazyLoad.load({
					name: 'EncounterDiagnosisModule',
					files: ['/mobiledoc/inpatientWeb/assets/registration/appointment/js/encounterDiagnosisController.js',
					        '/mobiledoc/jsp/inpatientWeb/templates/CPT-ICDAutoSuggest.js'],
					        cache: true
				}).then(function() {
					var url = '/mobiledoc/inpatientWeb/assets/registration/appointment/views/setDiagnosis.html';            		
					$scope.patientEncServiceType = makeURL(url);
				},function(e){ 
					console.log(e);
				} 
				);

			};

			$scope.patientEncounterServiceModal = function(index){
				$scope.diagnosisIndex = index;
				$scope.patientEncServiceType = "";
				$scope.dirty_flag = $scope.CheckField($scope.newEncounterData.serviceType,"serviceType","select");
				if($scope.dirty_flag){
					$scope.alertmsg = " Please select  Service Type ";	
				}else{
					$ocLazyLoad.load({
						name: 'patientEncounterServiceModule',
						files: ['/mobiledoc/jsp/inpatientWeb/templates/pagination-tpl.js',
						        '/mobiledoc/inpatientWeb/assets/registration/appointment/js/serviceTypeController.js'],
						        cache: true
					}).then(function() {
						var url = '/mobiledoc/inpatientWeb/assets/registration/appointment/views/serviceTypeEncounter.html';            		
						$scope.patientEncServiceType = makeURL(url);
					},function(e){ 
						console.log(e);
					} 
					);
				}
			};
		
			$scope.resetEncounterStatus = function(jsonObject){
				for (var i=0;i<jsonObject.length;i++)
				{
					jsonObject[i].dateAndTime = '';
					jsonObject[i].user = '';
					jsonObject[i].encMomentDate = '';
				}
				$scope.setDefaultStatus();
				return jsonObject;
			}; 
			
			$scope.showUnderDevlopmentMsg = function() {
				showIPMessage( 'This functionality is under development.', 'AlertMsg');
			}
			$scope.getSerDeptMapping = function(type){
				setCurrentLocation('dept');
				if(type == 'Dept'){
					$scope.encServiceType = {};
					$scope.DisplayDataJson.serviceType = 'Select';
					$scope.setResetUnit();
					resetServiceType();
				}
				$scope.disabledUnitBed = false;
				$scope.SerNameMandate = false;
			}
			$scope.updatePtInfoVerified = function(value){
				$scope.newEncounterData.verifyPtInfoUser = global.TrUserId;
				$scope.newEncounterData.verifyPtInfoTime = getDateTime();
				if($scope.newEncounterData.masterEncId != undefined && $scope.newEncounterData.masterEncId > 0){
					$scope.newEncounterData.changeFlag = true;	
				}
				var params = {'ptId':$scope.selectedPatient.ptId,'masterEncId':$scope.newEncounterData.masterEncId,'value':value,'dateAndTime':$scope.newEncounterData.verifyPtInfoTime,'nUserId':$scope.newEncounterData.verifyPtInfoUser};
				newApptService.updatePtInfoVerified(params).success(function(response){
					if(response.responseCount == 1){
						$scope.newEncounterData.ptInfoVerified = false;
						$scope.newEncounterData.verifyPtInfoUser = 0;
						showIPMessage( 'Patient is unknown.', 'AlertMsg');
					}
				});
			}
			$scope.currentPage  = {value : 1};
			$scope.rowsPerPage = {value : 10};
			$scope.totalRows = {value : 100};
			$scope.serviceName = '';
		    $scope.getServiceNameServiceModal = function( calledSource,searchText){
		    	if(calledSource == 'Search'){
		    		$scope.currentPage.value = 1;
		    	}
				var serviceDetails = {
						'serviceTypeId':$scope.newEncounterData.serviceType,
						'ServiceName':searchText,
						'counter' : $scope.currentPage.value+"",
						'MAXCOUNT' : $scope.rowsPerPage.value+""
				};
				newApptService.getServiceDetails(serviceDetails).success(function(response){
					if(response != null && response != undefined ){
						$scope.serviceNameDetails= response.ServicelistData;
						if($scope.serviceNameDetails.length > 0){
							$scope.SerNameMandate = true;	
						}else{
							$scope.SerNameMandate = false;
						}
						$scope.totalRows.value = response.TotalCount;
						
					}else{
						$scope.serviceNameDetails = [];
						$scope.SerNameMandate = false;
						$scope.totalRows.value = 0;
					}
				})
				.error(function(e) {
					$scope.SerNameMandate = false;
					console.log('error '+e);
				});
			};
			
			 var createICDXml = function(searchBy,code,description,counter,maxCount) {
                 var xw = new XMLWriter('ISO-8859-1', '1.0');
                 startSoapPacket(xw);
                 xw.writeStartElement('lookup');
                 xw.writeAttributeString('xsi:type', 'xsd:string');
                 addElement(xw, 'searchBy', searchBy, 'xsi:type', 'xsd:string');
                 if (searchBy === 'code')
                     addElement(xw, 'code', code, 'xsi:type', 'xsd:string');
                 else if (searchBy === 'name')
                     addElement(xw, 'name', description, 'xsi:type', 'xsd:string');
                 addElement(xw, 'keyName', 'Assessments', 'xsi:type', 'xsd:string');
                 addElement(xw, 'ShowCodes', '1', 'xsi:type', 'xsd:string');
                 addElement(xw, 'ValidDate', '', 'xsi:type', 'xsd:string');
                 addElement(xw, 'counter', counter, 'xsi:type', 'xsd:string');
                 addElement(xw, 'maxcount', maxCount, 'xsi:type', 'xsd:string');
                 addElement(xw, 'StartWith', 'Contains', 'xsi:type', 'xsd:string');
                 xw.writeEndElement();
                 endSoapPacket(xw);
                 return xw.flush();
             };
             
             function getObrPtType(id){
     			for(var j=0;j<$scope.obrPtType.length;j++){
     				if(id==$scope.obrPtType[j]){
     					$scope.disableObrPtType = false;
         				break;	
     				}
     			}
     		}
             
             // Toggle function for slide tray
             $scope.detailtoggle = function() {
            	 $scope.showNewEncSidebar = !$scope.showNewEncSidebar;
            	 var icon = $("#detail-toggle-icon");
            	 var container = $("#dpend-encounter-container")
            	 if($scope.showNewEncSidebar) {
            		 $(icon).css("right","340px");
            		 $(container).css("right","0px");
            		 $(icon).addClass("active");
            	 }
            	 else {
            		 $(icon).css("right","0");
            		 $(container).css("right","-340px");
            		 $(icon).removeClass("active");
            	 }
             }
             $scope.showEncounterModal = function(){
            	 $('#dencounter').show();
            	 $('#instruction-sched').hide();
             }
             
             $scope.showInstructionModal = function(){
            	 $('#dencounter').hide();
            	 $scope.encounterTab = '';
            	 $scope.ServiceNameList = [];
            	 for(var j=0;j<$scope.servicenameDiagnosisMapping.length;j++){
            		 $scope.ServiceNameList.push($scope.servicenameDiagnosisMapping[j].serviceid);
            	 }
            		 
 				$ocLazyLoad.load({
 					name: 'serviceInstructionModule',
 					files: ['/mobiledoc/inpatientWeb/assets/registration/appointment/js/instructionController.js',
 					        '/mobiledoc/inpatientWeb/assets/registration/appointment/js/instructionService.js'],
 					        cache: true
 				}).then(function() {
 					var url = '/mobiledoc/inpatientWeb/assets/registration/appointment/views/viewInstruction.html';            		
 					$scope.encounterTab = makeURL(url);
 				},function(e){ 
 					console.log(e);
 				} 
 				);
 				
 				

 			};
 			
 		    $scope.openMSPModal = function () {
 		    	var encDate = angular.copy( $scope.momentMasterAdmitDate.format("MM/DD/YYYY"));
 				var encMSPDate  = moment(encDate, "MM/DD/YYYY");
 		    	$ocLazyLoad.load({
 					name: 'medicalNecessityModule',
 					files: ['/mobiledoc/jsp/inpatientWeb/staticContent/js/vendor/perfect-scrollbar.jquery.min.js',
 						'/mobiledoc/jsp/inpatientWeb/staticContent/js/angularjs/angular-perfect-scrollbar.js',
 							'/mobiledoc/jsp/inpatientWeb/registration/js/medicalNecessityService.js',
 							'/mobiledoc/jsp/inpatientWeb/registration/js/medicalNecessityController.js'],
 					        cache: true
 				}).then(function() {
 		        var modalInstance = $modal.open({
 		            templateUrl: '/mobiledoc/jsp/inpatientWeb/registration/appointment/views/medicalNecessityModal.html',
 		            controller: 'medicalNecessityModalCtrl',
 		           controllerAs: 'ctrl',
 		            size: 'lg',
 		            backdrop: 'static',
 		            keyboard: false,
 		            windowClass: 'modal-w1000 project-10i-reg modalCtrl',
 		           resolve: {
 		        	  singleDateOpt: function () {
 		        	      return {encId:masterEncId,
 		        	    	 facId : $scope.selFacility.facility.Id,
 		        	    	 encounterDate:encMSPDate,
 		        	    	 singleDate:singleDateOpt
 		        	    	 };
 		        	    }
 		           }
 		        });
 		        modalInstance.result.then(function (getAttachedStatus) {
 		            if (getAttachedStatus.medNecessityStatus!=undefined) {
 		                if (getAttachedStatus.medNecessityStatus.onfile==true&&getAttachedStatus.medNecessityStatus.onfile!=undefined) {
 		                    $scope.showMed = false;
 		                    $scope.showOnfile = true;
 		                    $scope.showNotrequired = false;
 		                    $scope.showRequired = false;
 		                }else if(getAttachedStatus.medNecessityStatus.required==true&&getAttachedStatus.medNecessityStatus.required!=undefined){
 		                    $scope.showMed = false;
 		                    $scope.showOnfile = false;
 		                    $scope.showRequired = true;
 		                    $scope.showNotrequired = false;
 		                }
 		            }else{
 		                angular.forEach(getAttachedStatus.mapData,function(obj){
 		                    if (obj.icdAbn != 'No') {
 		                        $scope.showMed = true;
 		                        $scope.showNotrequired = false;
 		                       $scope.showOnfile = false;
 		                       $scope.showRequired = false;
 		                    }else{
 		                       $scope.showNotrequired = true;
 		                       $scope.showMed = false;
 		                       $scope.showOnfile = false;
 		                       $scope.showRequired = false;
 		                    }
 		                })
 		            }

 		        })
 		    })
 		    };
 			
	}
})()

angular.module('patientEncounterModule').directive('encRightPanel', ['$http',function ($modal, $ocLazyLoad,$http) {
	 return {
	      restrict: 'EA',
	      scope: {
	          ptdata: '=?',
	          encid: '=?',
	          openMspFn:"&openMspFn"
	       },
	      templateUrl: '/mobiledoc/inpatientWeb/assets/registration/appointment/views/encRightPanel.html',
	      controller: function($scope,$http) {
	    	  $scope.disableCostEstimator = true;
	    	  
	    	  $scope.initData = function(){
	    		  if($scope.encid != parseInt($scope.encid, 10))
	    			  $scope.encid = 0;
	    		  
	    		  var url=makeURL('/mobiledoc/inpatientWeb/EncRightPanel/getBalanceData/'+global.TrUserId+'/'+$scope.encid+'/'+$scope.ptdata.ptId);
		    		$http({
	                    method: 'GET',
	                    url: url
	                }).then(function(response){
	                	$scope.billingData = response.data; 
	                	if($scope.billingData && $scope.billingData.selfPay=='1'){
	                		$scope.disableCostEstimator = false;
	                	}
	                });
	    	  }
	    	  $scope.initData();
	    		
	    	  $scope.getDetailedPmt = function() {
	    	      $scope.detailedInfoRequested=true;
		           var url=makeURL('/mobiledoc/inpatientWeb/EncRightPanel/getPaymentDetails/'+$scope.encid);
			    	$http({
		                 method: 'GET',
		                 url: url
		            }).then(function(response){
		              	$scope.pmtDetails = response.data;
		               	if($scope.pmtDetails && $scope.pmtDetails.length==0)
		               		$scope.detailedInfoRequested=false;
		            });
		       }
		  },
		  link: function($scope,$http, element, attrs) {
	            $scope.detailtoggle = function() {
	                $scope.$parent.detailtoggle();
	            }
	            $scope.openMSPModal = function(){
	            	$scope.openMspFn();
	            }
	        }
	  };
}]
);


